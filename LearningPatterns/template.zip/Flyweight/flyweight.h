#pragma once

#ifndef FLYWEIGHT_FLYWEIGHT_H
#define FLYWEIGHT_FLYWEIGHT_H

namespace Flyweight {



} // namespace Flyweight

#endif // !FLYWEIGHT_FLYWEIGHT_H
