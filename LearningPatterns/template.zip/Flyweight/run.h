#pragma once

#ifndef FLYWEIGHT_RUN_H
#define FLYWEIGHT_RUN_H

namespace Flyweight {

void Run();

} // namespace Flyweight

#endif // !FLYWEIGHT_RUN_H
