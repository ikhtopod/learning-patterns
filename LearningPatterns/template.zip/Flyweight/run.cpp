#include "run.h"

namespace Flyweight {

void Run() {

}

} // namespace Flyweight
